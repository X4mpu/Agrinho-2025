let emojis = []; // Array para guardar os objetos de emoji
let emojiTipos = ['🌿', '🌱', '🍃', '💧']; // Adicionei a gotinha tbm, se quiser!

function setup() {
  // MUITO IMPORTANTE: Se você quer APENAS emojis HTML, e não um canvas, use noCanvas().
  // Se quiser um canvas p5.js E os emojis, REMOVA noCanvas() e mantenha a div container.
  noCanvas(); // Desativa a criação do canvas p5.js

  for (let i = 0; i < 30; i++) { // Cria 30 emojis caindo
    emojis.push(new EmojiItem(random(emojiTipos))); // Cria um novo emoji e adiciona ao array
  }
}

function draw() {
  // A função draw do p5.js ainda roda, mas agora só atualiza a posição dos emojis
  for (let emoji of emojis) {
    emoji.move();
    emoji.updatePosition(); // Atualiza a posição do elemento HTML
  }
}

class EmojiItem {
  constructor(emojiChar) {
    this.emojiChar = emojiChar;
    this.x = random(windowWidth); // Posição X inicial aleatória (usa a largura da janela)
    this.y = random(-200, 0); // Posição Y inicial (acima da tela)
    this.speed = random(1, 3);
    this.size = random(1.5, 3.5); // Tamanho do emoji (em 'em' unidades de fonte)

    // Cria um elemento span com o emoji
    this.element = createSpan(this.emojiChar);

    // ESSENCIAL para posicionar livremente e usar z-index
    this.element.style('position', 'absolute');
    this.element.style('font-size', this.size + 'em');
    this.element.style('opacity', random(0.6, 1));
    this.element.style('pointer-events', 'none'); // Faz com que o emoji não seja "clicável" e não bloqueie o texto
    this.element.style('user-select', 'none'); // Impede que o emoji seja selecionado com o mouse
    this.element.style('z-index', '-1'); // COLOCA O EMOJI ATRÁS DO CONTEÚDO PRINCIPAL
  }

  move() {
    this.y += this.speed;
    if (this.y > windowHeight) { // Se o emoji sair da tela, reseta no topo
      this.y = random(-50, 0);
      this.x = random(windowWidth);
      this.speed = random(1, 3); // Reseta a velocidade também
    }
  }

  updatePosition() {
    // Atualiza a posição do elemento HTML
    this.element.position(this.x, this.y);
  }
}